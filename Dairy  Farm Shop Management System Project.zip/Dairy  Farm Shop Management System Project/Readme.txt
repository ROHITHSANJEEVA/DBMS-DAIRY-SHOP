How to run the Dairy Farm Shop Management System Project (DFSMS)
1. Download the zip file

2. Extract the file and copy dfsms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name dfsms

6. Import dfsms.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/dfsms

Admin Credential

Username: admin
Password: Test@123